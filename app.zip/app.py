import random
import getopt, sys
import datetime
import os.path
def leer(nombre_archivo):
    # Nombre del archivo de texto
    #nombre_archivo = "agosto_sin_repetidos.txt"

    # Crear una lista para almacenar los números
    numeros = []
    repetidos = []

    # Leer los números desde el archivo de texto y eliminar duplicados
    with open(nombre_archivo, 'r') as archivo:
        for linea in archivo:
            if len(linea.strip()) == 0 or linea.strip() == "\n":
                continue
            if not linea.strip().isnumeric():
                continue
            numero = int(linea.strip())
            if numero not in numeros:
                numeros.append(numero)
            else:
                repetidos.append(numero)
    if len(repetidos) > 0:
        print("Existen ID set repetidos", repetidos)
        archivo_salida = f"repetidos_({nombre_archivo})"
        escribir(repetidos, archivo_salida)
        #for numero in repetidos:
            # print(numero)
    return numeros


def aleatorio(numeros, archivo_salida, n):
    inicio = 0
    fin = len(numeros) - 1
    indices = list(range(inicio, fin))

    random.shuffle(indices)
    # Generar el nombre del archivo con la fecha y hora
    nombre_archivo = f"aleatorios_({archivo_salida})"

    indices_imprimir = indices[:n]
    new_numeros = []
    for indice in indices_imprimir:
        new_numeros.append(numeros[indice])

    escribir(new_numeros, nombre_archivo)

    return random.randint(inicio, fin)

def escribir(numeros, archivo_salida):
    fecha_hora_actual = datetime.datetime.now()
    formato_fecha_hora = fecha_hora_actual.strftime("%Y-%m-%d_%H-%M-%S")  # Formato: AAAA-MM-DD_HH-MM-SS
    nombre_archivo = f"{archivo_salida}_{formato_fecha_hora}.txt"
    with open(nombre_archivo, 'w') as archivo:
        for numero in numeros:
            archivo.write(str(numero) + "\n")
    print("Se ha escrito la información en el archivo:", nombre_archivo)

def main(argv):
    # Definir los valores iniciales de los argumentos
    archivo_entrada = ""
    cantidad_numerica = 0

    try:
        # Obtener los argumentos de la línea de comandos
        opts, args = getopt.getopt(argv, "hi:n:", ["input=", "numero="])
    except getopt.GetoptError:
        print("Uso: mi_script.py -i <archivo_entrada> -n <numero>")
        sys.exit(2)

    # Procesar los argumentos obtenidos
    for opt, arg in opts:
        if opt == '-h':
            print("Uso: mi_script.py -i <archivo_entrada> -n <numero>")
            sys.exit()
        elif opt in ("-i", "--input"):
            archivo_entrada = arg
        elif opt in ("-n", "--numero"):
            try:
                cantidad_numerica = int(arg)
            except ValueError:
                print("El segundo argumento debe ser un número entero.")
                sys.exit(2)

    # Verificar que se hayan proporcionado todos los argumentos
    if not archivo_entrada or cantidad_numerica <= 0:
        print("Error en argumentos. La cantidad debe ser mayor a 0, o faltan argumentos. Uso: mi_script.py -i <archivo_entrada> -n <numero>")
        sys.exit(2)
    if not os.path.isfile(archivo_entrada):
        print("El archivo de entrada no existe.")
        sys.exit(2)


    # Ahora puedes utilizar los valores de los argumentos en tu programa
    print("Archivo de entrada:", archivo_entrada)
    print("Cantidad numérica:", cantidad_numerica)
    numeros = leer(archivo_entrada)
    #print("Numeros aleatorios:", numeros)
    aleatorio(numeros, archivo_entrada, cantidad_numerica)

if __name__ == "__main__":
    main(sys.argv[1:])